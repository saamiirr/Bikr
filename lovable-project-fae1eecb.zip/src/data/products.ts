import p1 from "@/assets/product-1.jpg";
import p2 from "@/assets/product-2.jpg";
import p3 from "@/assets/product-3.jpg";
import p4 from "@/assets/product-4.jpg";

export type Category = "women" | "men" | "oriental";

export type Product = {
  id: string;
  name: string;
  tagline: string;
  price: number;
  image: string;
  description: string;
  notes: { top: string[]; middle: string[]; base: string[] };
  category: Category;
};

const images = [p1, p2, p3, p4];
const img = (i: number) => images[i % images.length];

const mk = (
  id: string,
  name: string,
  tagline: string,
  price: number,
  category: Category,
  i: number,
  description: string,
  notes: { top: string[]; middle: string[]; base: string[] },
): Product => ({ id, name, tagline, price, image: img(i), description, notes, category });

export const products: Product[] = [
  // 🌸 Women
  mk("coco-chanel", "Coco Chanel", "Iconic oriental femininity.", 240, "women", 0,
    "A timeless oriental composition layering rose, jasmine and warm amber for an unmistakably feminine sillage.",
    { top: ["Bergamot", "Orange Blossom"], middle: ["Rose", "Jasmine", "Mimosa"], base: ["Amber", "Sandalwood", "Vanilla"] }),
  mk("si-passione", "Sì Passione", "Vibrant red velvet bloom.", 230, "women", 1,
    "A vibrant floral chypre with pear nectar, heart of rose and a sensual base of vanilla and musk.",
    { top: ["Pear", "Blackcurrant"], middle: ["Rose Absolute", "Geranium"], base: ["Vanilla", "Musk", "Patchouli"] }),
  mk("good-girl", "Good Girl", "Bold tuberose by night.", 220, "women", 2,
    "Tuberose and jasmine sambac wrapped in tonka and cocoa — a confident, after-dark statement.",
    { top: ["Almond", "Coffee"], middle: ["Tuberose", "Jasmine Sambac"], base: ["Cocoa", "Tonka", "Sandalwood"] }),
  mk("sexy-graffiti", "Sexy Graffiti", "Playful sweet floral burst.", 180, "women", 3,
    "A playful sweet floral with red berries, peony and a creamy musky drydown.",
    { top: ["Raspberry", "Pink Pepper"], middle: ["Peony", "Rose"], base: ["White Musk", "Vanilla"] }),
  mk("moon-sparkle", "Moon Sparkle", "Luminous floral musk.", 190, "women", 0,
    "A luminous, powdery floral that glows on the skin like moonlight on silk.",
    { top: ["Lychee", "Bergamot"], middle: ["Peony", "Magnolia"], base: ["White Musk", "Cedar"] }),
  mk("midnight-rose", "Midnight Rose", "Dark velvet rose noir.", 210, "women", 1,
    "A darker take on rose, threaded with blackcurrant and patchouli for an intimate, velvety trail.",
    { top: ["Blackcurrant", "Raspberry"], middle: ["Damascena Rose", "Violet"], base: ["Patchouli", "Amber"] }),
  mk("coco-vanille", "Coco Vanille", "Creamy coconut & vanilla.", 200, "women", 2,
    "A gourmand cloud of coconut milk, Madagascar vanilla and warm tonka — addictive and sun-soft.",
    { top: ["Coconut", "Almond"], middle: ["Vanilla Orchid", "Heliotrope"], base: ["Tonka", "Sandalwood", "Musk"] }),

  // 👔 Men (French)
  mk("sauvage", "Sauvage", "Raw freshness, ambroxan trail.", 250, "men", 3,
    "A radically fresh composition of Calabrian bergamot and ambroxan — magnetic and effortlessly masculine.",
    { top: ["Calabrian Bergamot", "Pepper"], middle: ["Sichuan Pepper", "Lavender", "Geranium"], base: ["Ambroxan", "Cedar", "Labdanum"] }),
  mk("black-xs", "Black XS", "Rock-edge dark floral.", 180, "men", 0,
    "A rock-inspired oriental with tagete, praline and a smooth amber backbone.",
    { top: ["Lemon", "Cinnamon"], middle: ["Tagete", "Praline"], base: ["Amber", "Tonka", "Patchouli"] }),
  mk("ultra-male", "Ultra Male", "Sweet fougère, club energy.", 220, "men", 1,
    "A sweet, electric fougère of lavender, pear and vanilla designed for the dancefloor.",
    { top: ["Lavender", "Pear", "Mint"], middle: ["Cinnamon", "Cardamom"], base: ["Vanilla", "Tonka", "Amber"] }),
  mk("voyage", "Voyage", "Crisp aquatic woods.", 170, "men", 2,
    "A crisp aquatic woody scent for the modern traveler — clean, confident, day-to-night.",
    { top: ["Sea Notes", "Bergamot"], middle: ["Cardamom", "Geranium"], base: ["Cedar", "Vetiver", "Musk"] }),
  mk("acqua-di-gio", "Acqua di Gio", "Mediterranean sea breeze.", 230, "men", 3,
    "An aromatic marine classic — citrus, sea spray and warm woods straight from the Mediterranean.",
    { top: ["Marine Notes", "Bergamot", "Neroli"], middle: ["Rosemary", "Jasmine"], base: ["Patchouli", "Cedar", "Musk"] }),
  mk("le-male-elixir", "Le Male Elixir", "Lavender honey tobacco.", 260, "men", 0,
    "A rich elixir of lavender, honey and tonka with a smoky tobacco finish.",
    { top: ["Lavender", "Mint"], middle: ["Honey", "Cinnamon"], base: ["Tonka", "Tobacco", "Benzoin"] }),
  mk("stronger-with-you", "Stronger With You", "Spicy chestnut, glass note.", 240, "men", 1,
    "A spicy oriental with pink pepper, lavender and a gourmand chestnut-vanilla drydown.",
    { top: ["Pink Pepper", "Cardamom"], middle: ["Lavender", "Violet"], base: ["Chestnut", "Vanilla", "Cedar"] }),
  mk("sculpture", "Sculpture", "Sleek powdery oriental.", 175, "men", 2,
    "A sculpted oriental — peach blossom, cedar and amber carved into a clean, lasting silhouette.",
    { top: ["Peach", "Bergamot"], middle: ["Cedar", "Iris"], base: ["Amber", "Sandalwood", "Musk"] }),
  mk("zara-gold", "Zara Gold", "Modern golden oud.", 160, "men", 3,
    "A modern, polished oud with saffron, leather and a touch of vanilla warmth.",
    { top: ["Saffron", "Bergamot"], middle: ["Oud", "Leather"], base: ["Vanilla", "Amber", "Musk"] }),
  mk("lacoste-white", "Lacoste White", "Crisp clean cotton.", 185, "men", 0,
    "An effortlessly clean composition — green apple, cedar and ylang for daily refinement.",
    { top: ["Green Apple", "Grapefruit"], middle: ["Ylang-Ylang", "Rosemary"], base: ["Cedar", "Vetiver", "Musk"] }),
  mk("creed-aventus", "Creed Aventus", "Smoky pineapple icon.", 320, "men", 1,
    "The legendary blend of pineapple, birch and oakmoss — bold, smoky and unmistakably regal.",
    { top: ["Pineapple", "Bergamot", "Blackcurrant"], middle: ["Birch", "Rose", "Jasmine"], base: ["Oakmoss", "Musk", "Vanilla"] }),
  mk("boss-the-scent", "Boss The Scent", "Magnetic ginger leather.", 210, "men", 2,
    "A magnetic men's signature with ginger, exotic maninka fruit and warm leather.",
    { top: ["Ginger", "Mandarin"], middle: ["Maninka Fruit", "Lavender"], base: ["Leather", "Cacao"] }),

  // 🕌 Oriental & Oud (unisex)
  mk("powder-musk", "Powder Musk", "Soft skin-musk veil.", 200, "oriental", 3,
    "A skin-close powdery musk that breathes like clean linen and warm cashmere.",
    { top: ["Aldehydes", "Bergamot"], middle: ["Iris", "Heliotrope"], base: ["White Musk", "Sandalwood"] }),
  mk("oud-bouquet", "Oud Bouquet", "Rose & oud bouquet.", 280, "oriental", 0,
    "A floral oud bouquet — Taifi rose entwined with smoky oud and warm amber.",
    { top: ["Saffron", "Bergamot"], middle: ["Taifi Rose", "Oud"], base: ["Amber", "Musk", "Sandalwood"] }),
  mk("madawi", "Madawi", "Honeyed oud opulence.", 290, "oriental", 1,
    "An opulent honeyed oud with saffron, dates and a long, resinous drydown.",
    { top: ["Saffron", "Bergamot"], middle: ["Honey", "Dates", "Rose"], base: ["Oud", "Amber", "Sandalwood"] }),
  mk("turab-al-dhahab", "Turab Al Dhahab", "Golden desert earth.", 270, "oriental", 2,
    "Golden earth of the desert — incense, gilded woods and a whisper of saffron.",
    { top: ["Incense", "Saffron"], middle: ["Rose", "Oud"], base: ["Amber", "Sandalwood", "Musk"] }),
  mk("kalemat", "Kalemat", "Words of warm amber.", 260, "oriental", 3,
    "A warm amber composition of honey, vanilla and oriental spices — soft as whispered words.",
    { top: ["Honey", "Bergamot"], middle: ["Spices", "Rose"], base: ["Amber", "Vanilla", "Musk"] }),
  mk("oud-abyad", "Oud Abyad", "White oud, luminous wood.", 300, "oriental", 0,
    "A luminous white oud — cleaner, brighter, layered with citrus and creamy sandalwood.",
    { top: ["Lemon", "Saffron"], middle: ["White Oud", "Rose"], base: ["Sandalwood", "Amber", "Musk"] }),
  mk("bm", "BM", "Signature Bikr Maison.", 320, "oriental", 1,
    "The signature of Maison Bikr — oud, rose, amber and immaculate alcohol composed into a private trail.",
    { top: ["Saffron", "Bergamot", "Pink Pepper"], middle: ["Rose", "Oud", "Jasmine"], base: ["Amber", "Sandalwood", "Musk"] }),
];

export const getProduct = (id: string) => products.find((p) => p.id === id);